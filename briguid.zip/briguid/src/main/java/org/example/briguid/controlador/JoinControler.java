package org.example.briguid.controlador;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.briguid.modelo.dao.UsuarioDao;

import java.io.IOException;

public class JoinControler {
    @FXML
    private TextField campoId;
    @FXML
    private PasswordField campoContraseña;

    private UsuarioDao usuarioDao;

    public JoinControler() {
        usuarioDao = new UsuarioDao();
    }

    @FXML
    private void initialize() {
    }

    @FXML
    private void iniciarSesion() throws IOException {
        String id = campoId.getText();
        String contraseña = campoContraseña.getText();

        if (usuarioDao.validarCredenciales(id, contraseña)) {
            mostrarAlerta("Inicio de sesión exitoso", "¡Bienvenido, " + id + "!");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/briguid/hello-view.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) campoId.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } else {
            mostrarAlerta("Error de inicio de sesión", "Credenciales inválidas. Por favor, inténtalo de nuevo.");
            limpiar();

        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
    private void limpiar(){
        campoId.clear();
        campoContraseña.clear();
    }
}
