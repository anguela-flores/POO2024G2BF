package org.example.briguid.controlador;

import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.briguid.modelo.dao.clienteDao;
import org.example.briguid.modelo.dominio.cliente;
import org.example.briguid.modelo.dominio.clienteVip;
import org.example.briguid.util.BaseDatos;

public class HelloController {
    @FXML
    private TableView<cliente> tablaClientes;
    @FXML
    private TableColumn<cliente, String> columnaDniRuc;
    @FXML
    private TableColumn<cliente, String> columnaNombre;
    @FXML
    private TableColumn<cliente, String> columnaApellido;
    @FXML
    private TableColumn<cliente, String> columnaTelefono;
    @FXML
    private TableColumn<cliente, String> columnaTipo;
    @FXML
    private TableColumn<cliente, String> columnavip;
    @FXML
    private TextField campobuscador;
    @FXML
    private TextField campoDniRuc;
    @FXML
    private TextField campoNombre;
    @FXML
    private TextField campoApellido;
    @FXML
    private TextField campoTelefono;
    @FXML
    private ComboBox campoTipo;

    private clienteDao dao;

    public HelloController() {
        dao = new clienteDao(new BaseDatos());
    }

    @FXML
    private void initialize() {
        tablaClientes.setItems(dao.obtenerClientes());
        columnaDniRuc.setCellValueFactory(cellData -> cellData.getValue().dniRucProperty());
        columnaNombre.setCellValueFactory(cellData -> cellData.getValue().nombreProperty());
        columnaApellido.setCellValueFactory(cellData -> cellData.getValue().apellidoProperty());
        columnaTelefono.setCellValueFactory(cellData -> cellData.getValue().telefonoProperty());
        columnaTipo.setCellValueFactory(cellData -> cellData.getValue().tipoProperty());

        tablaClientes.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                mostrarClienteSeleccionado(newValue);
            }
        });
    }

    private void mostrarClienteSeleccionado(cliente clienteSeleccionado) {
        campoDniRuc.setText(clienteSeleccionado.getDniRuc());
        campoNombre.setText(clienteSeleccionado.getNombre());
        campoApellido.setText(clienteSeleccionado.getApellido());
        campoTelefono.setText(clienteSeleccionado.getTelefono());
        campoTipo.getSelectionModel().select(clienteSeleccionado.getTipo());
    }


    @FXML
    private void agregarCliente() {
        String dniRuc = campoDniRuc.getText();
        String nombre = campoNombre.getText();
        String apellido = campoApellido.getText();
        String telefono = campoTelefono.getText();
        String tipo = (String) campoTipo.getValue();

        dao.agregarCliente(dniRuc,nombre, apellido, telefono,tipo);

        // Limpiar campos
        limpiarCampos();

        // Actualizar la tabla
        tablaClientes.setItems(dao.obtenerClientes());
        tablaClientes.refresh(); // Actualizar la tabla
        initialize();
    }


    @FXML
    private void buscarCliente(){
        String dniRucABuscar = campobuscador.getText();
        if (!dniRucABuscar.isEmpty()) {
            cliente clienteEncontrado = dao.buscarCliente(dniRucABuscar);
            if (clienteEncontrado != null) {
                mostrarClienteEncontrado(clienteEncontrado);
            } else {
                mostrarAlerta("Cliente no encontrado", "No se encontró ningún cliente con el DNI/RUC especificado.");
            }
        } else {
            mostrarAlerta("Campo vacío", "Por favor, ingrese un DNI/RUC para buscar.");
        }
    }

    private void mostrarClienteEncontrado(cliente clienteEncontrado) {
        campoDniRuc.setText(clienteEncontrado.getDniRuc());
        campoNombre.setText(clienteEncontrado.getNombre());
        campoApellido.setText(clienteEncontrado.getApellido());
        campoTelefono.setText(clienteEncontrado.getTelefono());
        campoTipo.getSelectionModel().select(clienteEncontrado.getTipo());
    }
    @FXML
    private void eliminarCliente() {
        cliente clienteSeleccionado = tablaClientes.getSelectionModel().getSelectedItem();
        if (clienteSeleccionado != null) {
            dao.eliminarCliente(clienteSeleccionado.getDniRuc());
            initialize();
        } else {
            mostrarAlerta("Error", "Seleccione un cliente para eliminar.");
        }
    }
    @FXML
    private void ActualizarRegistro() {
        cliente clienteSeleccionado = tablaClientes.getSelectionModel().getSelectedItem();
        if (clienteSeleccionado != null) {
            String nuevoDniRuc= campoDniRuc.getText();
            String nuevoNombre = campoNombre.getText();
            String nuevoApellido = campoApellido.getText();
            String nuevoTelefono = campoTelefono.getText();
            String nuevoTipo = (String) campoTipo.getSelectionModel().getSelectedItem();
            if (nuevoNombre.isEmpty() || nuevoApellido.isEmpty() || nuevoTelefono.isEmpty() || nuevoTipo.isEmpty()) {
                mostrarAlerta("Error", "Complete todos los campos para actualizar el cliente.");
                return;
            }
            dao.actualizarCliente(clienteSeleccionado.getDniRuc(), nuevoNombre, nuevoApellido, nuevoTelefono, nuevoTipo);
            clienteSeleccionado.setDniRuc(nuevoDniRuc);
            clienteSeleccionado.setNombre(nuevoNombre);
            clienteSeleccionado.setApellido(nuevoApellido);
            clienteSeleccionado.setTelefono(nuevoTelefono);
            clienteSeleccionado.setTipo(nuevoTipo);
            tablaClientes.refresh();
        } else {
            mostrarAlerta("Error", "Seleccione un cliente para editar.");
        }
        limpiarCampos();
    }


    private void limpiarCampos() {
        campoDniRuc.clear();
        campoNombre.clear();
        campoApellido.clear();
        campoTelefono.clear();
        campoTipo.getSelectionModel().clearSelection();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}
