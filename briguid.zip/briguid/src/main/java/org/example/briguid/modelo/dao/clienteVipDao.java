package org.example.briguid.modelo.dao;

public class clienteVipDao {
}
