package org.example.briguid.modelo.dominio;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;

public class cliente {
    private String dniRuc;
    private String nombre;
    private String apellido;
    private String telefono;
    private String tipo;

    public cliente(String dniRuc, String nombre, String apellido, String telefono, String tipo) {
        this.dniRuc = dniRuc;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.tipo = tipo;
    }

    public String getDniRuc() {
        return dniRuc;
    }

    public void setDniRuc(String dniRuc) {
        this.dniRuc = dniRuc;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public StringProperty dniRucProperty() {
        return new SimpleStringProperty(dniRuc);
    }

    public StringProperty nombreProperty() {
        return new SimpleStringProperty(nombre);
    }

    public StringProperty apellidoProperty() {
        return new SimpleStringProperty(apellido);
    }

    public StringProperty telefonoProperty() {
        return new SimpleStringProperty(telefono);
    }

    public StringProperty tipoProperty() {
        return new SimpleStringProperty(tipo);
    }
    @Override
    public String toString() {
        return "Cliente{" +
                "dniRuc='" + dniRuc + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", telefono='" + telefono + '\'' +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}
