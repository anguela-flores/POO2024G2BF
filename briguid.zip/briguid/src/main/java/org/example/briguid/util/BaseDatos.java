package org.example.briguid.util;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.briguid.modelo.dominio.cliente;
import org.example.briguid.modelo.dominio.clienteVip;

public class BaseDatos {
    private ObservableList<cliente> listaClientes;

    public BaseDatos() {
        this.listaClientes = FXCollections.observableArrayList();
        listaClientes.add(new cliente("76606525", "Jhosue", "Pastor", "30", "Tipo 5"));
        listaClientes.add(new cliente("12345678", "María", "Gómez", "12345678", "Tipo 1"));
        listaClientes.add(new cliente("87654321", "Juan", "Pérez", "87654321", "Tipo 2"));
        listaClientes.add(new cliente("98765432", "Ana", "Martínez", "98765432", "Tipo 3"));
        listaClientes.add(new cliente("23456789", "Carlos", "López", "23456789", "Tipo 4"));
        listaClientes.add(new cliente("34567890", "Laura", "Rodríguez", "34567890", "Tipo 5"));
        listaClientes.add(new cliente("45678901", "Pedro", "Sánchez", "45678901", "Tipo 6"));
        listaClientes.add(new cliente("56789012", "Luis", "González", "56789012", "Tipo 1"));
    }

    public void agregarCliente(cliente cliente) {
        listaClientes.add(cliente);
    }

    public void eliminarCliente(cliente cliente) {
        listaClientes.remove(cliente);
    }

    public ObservableList<cliente> obtenerClientes() {
        return listaClientes;
    }
}
