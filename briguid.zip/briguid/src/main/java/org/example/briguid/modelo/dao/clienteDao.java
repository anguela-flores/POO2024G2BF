package org.example.briguid.modelo.dao;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.briguid.modelo.dominio.cliente;
import org.example.briguid.util.BaseDatos;

import java.util.ArrayList;

public class clienteDao {
    private BaseDatos baseDatos;

    public clienteDao(BaseDatos baseDatos) {
        this.baseDatos = baseDatos;
    }

    public void agregarCliente(String dniRuc, String nombre, String apellido, String telefono, String tipo) {
        cliente nuevoCliente = new cliente(dniRuc, nombre, apellido, telefono, tipo);
        baseDatos.agregarCliente(nuevoCliente);
    }

    public void eliminarCliente(String dniRuc) {
        ArrayList<cliente> clientes = (ArrayList<cliente>) baseDatos.obtenerClientes();
        for (cliente c : clientes) {
            if (c.getDniRuc().equals(dniRuc)) {
                baseDatos.eliminarCliente(c);
                break;
            }
        }
    }

    public cliente buscarCliente(String dniRuc) {
        ArrayList<cliente> clientes = (ArrayList<cliente>) baseDatos.obtenerClientes();
        for (cliente c : clientes) {
            if (c.getDniRuc().equals(dniRuc)) {
                return c;
            }
        }
        return null;
    }

    public void actualizarCliente(String dniRuc, String nombre, String apellido, String telefono, String tipo) {
        cliente clienteExistente = buscarCliente(dniRuc);
        if (clienteExistente != null) {
            clienteExistente.setNombre(nombre);
            clienteExistente.setApellido(apellido);
            clienteExistente.setTelefono(telefono);
            clienteExistente.setTipo(tipo);
        }
    }
    public ObservableList<cliente> obtenerClientes() {
        return FXCollections.observableArrayList(baseDatos.obtenerClientes());
    }
}
