package org.example.briguid.modelo.dao;

import java.util.ArrayList;
import java.util.List;
import org.example.briguid.modelo.dominio.Usuario;

public class UsuarioDao {
    private List<Usuario> usuarios;

    public UsuarioDao() {

        usuarios = new ArrayList<>();

        usuarios.add(new Usuario("briguid", "123"));
        usuarios.add(new Usuario("jhosue", "123"));
    }

    public Usuario obtenerUsuarioPorId(String id) {
        for (Usuario usuario : usuarios) {
            if (usuario.getId().equals(id)) {
                return usuario;
            }
        }
        return null;
    }

    public boolean validarCredenciales(String id, String contraseña) {
        Usuario usuario = obtenerUsuarioPorId(id);
        return usuario != null && usuario.getContraseña().equals(contraseña);
    }
}
