package org.example.briguid.modelo.dominio;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class clienteVip extends cliente {
    private double descuento;

    public clienteVip(String dniRuc, String nombre, String apellido, String telefono, String tipo, double descuento) {
        super(dniRuc, nombre, apellido, telefono, tipo);
        this.descuento = descuento;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }
    public StringProperty descuentoProperty() {
        return new SimpleStringProperty();
    }
    @Override
    public String toString() {
        return "ClienteVIP{" +
                "dniRuc='" + getDniRuc() + '\'' +
                ", nombre='" + getNombre() + '\'' +
                ", apellido='" + getApellido() + '\'' +
                ", telefono='" + getTelefono() + '\'' +
                ", tipo='" + getTipo() + '\'' +
                ", descuento=" + descuento +
                '}';
    }
}