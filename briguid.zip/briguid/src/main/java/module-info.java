module org.example.briguid {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;

    opens org.example.briguid to javafx.fxml;
    exports org.example.briguid;
    exports org.example.briguid.controlador;
    opens org.example.briguid.controlador to javafx.fxml;
}